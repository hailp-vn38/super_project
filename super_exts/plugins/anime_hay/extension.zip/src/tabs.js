async function tabs() {
  return Response.success([
    {
      title: "Phim mới cập nhật",
      url: "/phim-moi-cap-nhap",
    },
    {
      title: "Phim lẻ",
      url: "/loc-phim/W1tdLFtdLFs5OTk5XSxbXV0=",
    },
    {
      title: "Hoàn thành",
      url: "/loc-phim/W1tdLFtdLFtdLFsxXV0=",
    },
  ]);
}
