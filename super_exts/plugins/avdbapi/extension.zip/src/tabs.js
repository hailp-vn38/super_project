async function tabs() {
  return Response.success([
    {
      title: "Mới cập nhật",
      url: "/api.php/provide/vod/?ac=detail",
    },
  ]);
}
