async function chapter(url) {
  return Response.success("");
}

// runFn(() =>
//   chapter(
//     "https://truyencv.info/bat-dau-tu-con-so-0-them-chut-tien-hoa/chuong-1/99600000"
//   )
// );
